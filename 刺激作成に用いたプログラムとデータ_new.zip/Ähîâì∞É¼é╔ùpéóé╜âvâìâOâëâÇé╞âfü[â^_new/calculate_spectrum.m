LED_spectrum=readmatrix('LED_20_stim_low.csv');
LED_20_stim=readmatrix("LED_low_stim.csv");
gamma=readmatrix('gamma.csv');
LED_stimulus_spectral_intensity=readmatrix("LED_stimulus_spectral_intensity.csv");
LED_stim=zeros([1 26]);
LED_stim_gamma=zeros([1 26]);
x=390:1:780;
for i=1:20
    calib_spectrum=zeros([1 391]);
    spectrum=zeros([1 391]);
    for j=1:26
        LED_stim(j)=LED_20_stim(i,j);
        LED_stim_gamma(j)=100*((LED_stim(j)/100)^gamma(j));
    end
    for j=1:391
        for k=1:26
            spectrum(j)=spectrum(j)+LED_stim_gamma(k)*LED_stimulus_spectral_intensity(k,j)/10;
        end
        calib_spectrum(j)=LED_spectrum(i,j);
    end
    plot(x,spectrum)
    hold on
    plot(x,calib_spectrum)
    legend("設計値","測光値")
    filename="i="+i+".png";
    saveas(gcf,filename);
    hold off
end
