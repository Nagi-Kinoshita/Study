function answer = Lab_f(t)
if t>(6/29)^3
    answer=t^(1/3);
else
    answer=(((29/3)^3)*t+16)/116;
end
end