%
% PAL_SDT_MAFCoddity_PCtoDP is no longer functional
%
% Use instead PAL_SDT_MAFCoddity_DiffMod_PCtoDP 
%
% Introduced: Palamedes version 1.0.0 (FK & NP)
% Modified: Palamedes version 1.0.1, 1.6.3, 1.8.0 (see History.m)

function out = PAL_SDT_MAFCoddity_PCtoDP(PC,M)

message = 'PAL_SDT_MAFCoddity_PCtoDP is no longer functional. Use ';
message = [message 'dP = PAL_SDT_MAFCoddity_DiffMod_PCtoDP(PC,M) instead '];
error(message);
out = [];