%
%PAL_ExampleFunction calculates the sum, difference, product, and ratio
%   of two scalars, vectors or matrices.
%
%   syntax: [sum difference product ratio] = ...
%       PAL_ExampleFunction(array1, array2)
%
%   This function serves no purpose other than to demonstrate the general 
%   usage of Matlab functions.
%
%Introduced: Palamedes version 1.0.0 (NP)

function [sum, difference, product, ratio] = PAL_ExampleFunction(array1, array2)

sum = array1 + array2;
difference = array1 - array2;
product = array1.*array2;
ratio = array1./array2;