%
% PAL_SDT_MAFCoddity_DPtoPC is no longer functional
%
% Use instead: PAL_SDT_MAFCoddity_DiffMod_DPtoPC 
%
% Introduced: Palamedes version 1.0.0 (FK & NP)
% Modified: Palamedes version 1.0.1, 1.6.3, 1.8.0 (see History.m)

function out = PAL_SDT_MAFCoddity_DPtoPC(dP,M)

message = 'PAL_SDT_MAFCoddity_DPtoPC is no longer functional. Use ';
message = [message 'PC = PAL_SDT_MAFCoddity_DiffMod_DPtoPC(dP,M) instead '];
error(message);
out = [];